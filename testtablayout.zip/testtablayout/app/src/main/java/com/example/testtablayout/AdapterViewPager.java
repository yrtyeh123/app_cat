package com.example.testtablayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;


public class AdapterViewPager extends FragmentPagerAdapter {
    private  int numPage;
    public AdapterViewPager(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
        numPage = behavior;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0: return new fragment_list();
            case 1: return new fragment_info();
            case 2: return new fragment_search();
        }
        return new fragment_list();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position){
            case 0: return "List";
            case 1: return "Info";
            case 2: return "Search";
        }
        return "List";
    }

    @Override
    public int getCount() {
        return numPage;
    }
}
