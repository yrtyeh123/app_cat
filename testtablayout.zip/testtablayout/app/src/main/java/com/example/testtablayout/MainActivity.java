package com.example.testtablayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    AdapterViewPager adapter;
    TabLayout tab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.viewPager);
        tab = findViewById(R.id.tab);
        adapter = new AdapterViewPager(getSupportFragmentManager(),3);
        viewPager.setAdapter(adapter);
        tab.setupWithViewPager(viewPager);

    }
}